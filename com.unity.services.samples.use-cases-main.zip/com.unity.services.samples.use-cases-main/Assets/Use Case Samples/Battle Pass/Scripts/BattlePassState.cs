using System;

namespace Unity.Services.Samples.BattlePass
{
    public class BattlePassState
    {
        public int seasonXP;
        public bool ownsBattlePass;
        public TierState[] tierStates;
    }
}
