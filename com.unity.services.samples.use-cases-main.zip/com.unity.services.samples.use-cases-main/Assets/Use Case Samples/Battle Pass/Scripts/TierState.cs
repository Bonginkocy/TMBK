using System;

namespace Unity.Services.Samples.BattlePass
{
    public enum TierState
    {
        Locked,
        Unlocked,
        Claimed,
    }
}
